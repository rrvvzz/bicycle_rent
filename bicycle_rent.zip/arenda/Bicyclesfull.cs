﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arenda
{
    public partial class Bicyclesfull : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlCommandBuilder sqlBuilder = null;

        private SqlDataAdapter adapter = null;

        private DataSet dataSet = null;

        private bool newRowAdding = false;
        private void LoadData()
        {
            try
            {
                adapter = new SqlDataAdapter("SELECT Bicycles.id AS 'Номер_велосипеда'," +
                    "typev_id AS 'Номер_категории'," +
                    "name_bi AS 'Название_велосипеда'," +
                    "kol_vo AS 'Количество_доступных_велосипедов', 'Delete' AS [Delete] FROM Bicycles", sqlConnection);

                sqlBuilder = new SqlCommandBuilder(adapter);

                sqlBuilder.GetInsertCommand();
                sqlBuilder.GetUpdateCommand();
                sqlBuilder.GetDeleteCommand();

                dataSet = new DataSet();

                adapter.Fill(dataSet, "Bicycles");

                dataGridView1.DataSource = dataSet.Tables["Bicycles"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[4, i] = linkCell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
        private void ReloadData()
        {
            try
            {
                dataSet.Tables["Bicycles"].Clear();

                adapter.Fill(dataSet, "Bicycles");

                dataGridView1.DataSource = dataSet.Tables["Bicycles"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[4, i] = linkCell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
        public Bicyclesfull()
        {
            InitializeComponent();
        }

        private void Bicyclesfull_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=ARENDA;Integrated Security=True");
            sqlConnection.Open();
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Sotrudnikmenu menu = new Sotrudnikmenu();
            menu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 4)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();

                    if (task == "Delete")
                    {
                        if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo)
                            == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);
                            dataSet.Tables["Bicycles"].Rows[rowIndex].Delete();
                            adapter.Update(dataSet, "Bicycles");
                        }
                    }
                    else if (task == "Insert")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;

                        DataRow row = dataSet.Tables["Bicycles"].NewRow();

                        row["Номер_велосипеда"] = dataGridView1.Rows[rowIndex].Cells["Номер_велосипеда"].Value;
                        row["Номер_категории"] = dataGridView1.Rows[rowIndex].Cells["Номер_категории"].Value;
                        row["Название_велосипеда"] = dataGridView1.Rows[rowIndex].Cells["Название_велосипеда"].Value;
                        row["Количество_доступных_велосипедов"] = dataGridView1.Rows[rowIndex].Cells["Количество_доступных_велосипедов"].Value;

                        dataSet.Tables["Bicycles"].Rows.Add(row);
                        dataSet.Tables["Bicycles"].Rows.RemoveAt(dataSet.Tables["Bicycles"].Rows.Count - 1);
                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                        dataGridView1.Rows[e.RowIndex].Cells[4].Value = "Delete";

                        adapter.Update(dataSet, "Bicycles");

                        newRowAdding = false;
                    }
                    else if (task == "Update")
                    {
                        int r = e.RowIndex;

                        dataSet.Tables["Bicycles"].Rows[r]["Номер_велосипеда"] = dataGridView1.Rows[r].Cells["Номер_велосипеда"].Value;
                        dataSet.Tables["Bicycles"].Rows[r]["Номер_категории"] = dataGridView1.Rows[r].Cells["Номер_категории"].Value;
                        dataSet.Tables["Bicycles"].Rows[r]["Название_велосипеда"] = dataGridView1.Rows[r].Cells["Название_велосипеда"].Value;
                        dataSet.Tables["Bicycles"].Rows[r]["Количество_доступных_велосипедов"] = dataGridView1.Rows[r].Cells["Количество_доступных_велосипедов"].Value;

                        adapter.Update(dataSet, "Bicycles");
                        dataGridView1.Rows[e.RowIndex].Cells[4].Value = "Delete";
                    }
                    ReloadData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                if (newRowAdding == false)
                {
                    newRowAdding = true;

                    int lastRaw = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRaw];
                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[4, lastRaw] = linkCell;
                    row.Cells["Delete"].Value = "Insert";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if ((newRowAdding == false))
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingRow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkCell = new DataGridViewLinkCell();
                    dataGridView1[4, rowIndex] = linkCell;
                    editingRow.Cells["Delete"].Value = "Update";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!");
            }
        }
    }
}
