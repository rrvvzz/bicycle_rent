﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arenda
{
    public partial class Bicycles : Form
    {
        private SqlConnection sqlConnection = null;
        public Bicycles()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Polzform polzform = new Polzform();
            polzform.Show();
        }

        private void Visible_obj()
        {
            label2.Visible = true;
            dataGridView1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;
            label3.Visible = false;
            button4.Visible = false;
            comboBox2.Visible = false;  
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
        }
        private void Visible_label()
        {
            label4.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            label8.Visible = true;
        }
        private void Hours()
        {
            label7.Text = Convert.ToString("Время аренды: " + comboBox2.Text + " Часа");
        }
        private void Fullprice()
        {
            sum = Convert.ToInt32(comboBox2.Text) * price;
            label8.Text = Convert.ToString("Итоговая стоимость: " + sum + " Руб");
        }

        private void Bicycles_Load(object sender, EventArgs e)
        {
            sqlConnection = new SqlConnection(@"Data Source=DESKTOP-QUNMPBA\SQL;Initial Catalog=ARENDA;Integrated Security=True");
            sqlConnection.Open();
            button2.Visible = false;
            button3.Visible = false;
            label3.Visible = false;
            comboBox2.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label6.Visible = false;
            label7.Visible = false;
            label8.Visible = false;
            button4.Visible = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    label2.Text = "Горные велосипеды";
                    Visible_obj();
                    pictureBox1.Load("1v.jpg");
                    pictureBox2.Load("2v.jpg");
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT name_bi AS 'Название велосипеда', " +
                            "opisanie AS 'Описание велосипеда', price AS 'Цена за час' " +
                            "FROM Bicycles JOIN Typev ON Typev.id = Bicycles.typev_id WHERE name_type = 'Горные'; ", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
                case 1:
                    label2.Text = "Детские велосипеды";
                    Visible_obj();
                    pictureBox1.Load("3v.jpg");
                    pictureBox2.Load("4v.jpg");
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT name_bi AS 'Название велосипеда', " +
                            "opisanie AS 'Описание велосипеда', price AS 'Цена за час' " +
                            "FROM Bicycles JOIN Typev ON Typev.id = Bicycles.typev_id WHERE name_type = 'Детские'; ", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
                case 2:
                    label2.Text = "Складные велосипеды";
                    Visible_obj();
                    pictureBox1.Load("5v.jpg");
                    pictureBox2.Load("6v.jpg");
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT name_bi AS 'Название велосипеда', " +
                            "opisanie AS 'Описание велосипеда', price AS 'Цена за час' " +
                            "FROM Bicycles JOIN Typev ON Typev.id = Bicycles.typev_id WHERE name_type = 'Складные'; ", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
                case 3:
                    label2.Text = "Женские велосипеды";
                    Visible_obj();
                    pictureBox1.Load("7v.jpg");
                    pictureBox2.Load("8v.jpg");
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT name_bi AS 'Название велосипеда', " +
                            "opisanie AS 'Описание велосипеда', price AS 'Цена за час' " +
                            "FROM Bicycles JOIN Typev ON Typev.id = Bicycles.typev_id WHERE name_type = 'Женские'; ", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
                case 4:
                    label2.Text = "Городские велосипеды";
                    Visible_obj();
                    pictureBox1.Load("9v.jpg");
                    pictureBox2.Load("10v.jpg");
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT name_bi AS 'Название велосипеда', " +
                            "opisanie AS 'Описание велосипеда', price AS 'Цена за час' " +
                            "FROM Bicycles JOIN Typev ON Typev.id = Bicycles.typev_id WHERE name_type = 'Городские'; ", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
                case 5:
                    label2.Text = "Электровелосипеды";
                    Visible_obj();
                    pictureBox1.Load("11v.jpg");
                    pictureBox2.Load("12v.jpg");
                    try
                    {
                        SqlDataAdapter adapter = new SqlDataAdapter("SELECT name_bi AS 'Название велосипеда', " +
                            "opisanie AS 'Описание велосипеда', price AS 'Цена за час' " +
                            "FROM Bicycles JOIN Typev ON Typev.id = Bicycles.typev_id WHERE name_type = 'Электровелосипеды'; ", sqlConnection);

                        DataTable table = new DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!");
                    }
                    break;
            }
        }
        int sum;
        int price;
        private void button2_Click(object sender, EventArgs e)
        {
            button3.Visible = false;
            label3.Visible = true;
            comboBox2.Visible = true;
            button4.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button2.Visible = false;
            label3.Visible = true;
            comboBox2.Visible = true;
            button4.Visible = true;
        }
        
        private void button4_Click(object sender, EventArgs e)
        {
            price = 150;
            label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
            label6.Visible = true;
            if (comboBox1.Text == "Горные")
            {
                if (button2.Visible == true)
                {
                    label4.Text = "Модель велосипеда: MERIDA Big.Nine 400";
                }
                else
                {
                    label4.Text = "Модель велосипеда: FORWARD NEXT 3.0";
                }
                price = 150;
                label5.Text = "Описание: Отличный вариант для загородных поездок";
                label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
                Hours();
                Fullprice();
                Visible_label();
            }
            if (comboBox1.Text == "Складные")
            {
                if (button2.Visible == true)
                {
                    label4.Text = "Модель велосипеда: AIST Smart 24 2.1";
                }
                else
                {
                    label4.Text = "Модель велосипеда: ALTAIR CITY 24";
                }
                price = 150;
                label5.Text = "Описание: Удобное, компактное средство передвижения";
                label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
                Hours();
                Fullprice();
                Visible_label();
            }
            if (comboBox1.Text == "Женские")
            {
                if (button2.Visible == true)
                {
                    label4.Text = "Модель велосипеда: STELS Miss 6000";
                }
                else
                {
                    label4.Text = "Модель велосипеда: FORWARD JADE 1.0";
                }
                price = 150;
                label5.Text = "Описание: Велосипеды для женщин с более низкой рамой";
                label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
                Hours();
                Fullprice();
                Visible_label();
            }
            if (comboBox1.Text == "Детские")
            {
                if (button2.Visible == true)
                {
                    label4.Text = "Модель велосипеда: AIST Serenity 1.0";
                }
                else
                {
                    label4.Text = "Модель велосипеда: AIST Pirate 2.0";
                }
                label5.Text = "Описание: Вариант для велопрогулок с детьми";
                price = 100;
                label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
                Hours();
                Fullprice();
                Visible_label();
            }
            if (comboBox1.Text == "Городские")
            {
                if (button2.Visible == true)
                {
                    label4.Text = "Модель велосипеда: BEARBIKE Marrakech";
                }
                else
                {
                    label4.Text = "Модель велосипеда: BEARBIKE Perm";
                }
                label5.Text = "Описание: Удобное и комфортное передвижение по городу";
                price = 200;
                label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
                Hours();
                Fullprice();
                Visible_label();
            }
            if (comboBox1.Text == "Электровелосипеды")
            {
                if (button2.Visible == true)
                {
                    label4.Text = "Модель велосипеда: Eltreco XT 600";
                }
                else
                {
                    label4.Text = "Модель велосипеда: Elbike Hummer Elite";
                }
                label5.Text = "Описание: Быстрое передвижение с малыми затратами сил";
                price = 300;
                label6.Text = Convert.ToString("Стоимость аренды за час: " + price + " Руб");
                Hours();
                Fullprice();
                Visible_label();
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex != 0)
            {
                button4.Enabled = true;
            }
        }
    }
}
